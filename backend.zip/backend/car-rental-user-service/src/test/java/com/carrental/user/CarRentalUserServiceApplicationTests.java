package com.carrental.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
