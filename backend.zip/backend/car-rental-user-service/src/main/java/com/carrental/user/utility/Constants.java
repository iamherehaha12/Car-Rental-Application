package com.carrental.user.utility;

public class Constants {

	public enum UserRole {
		ROLE_ADMIN("Admin"), ROLE_CUSTOMER("Customer"), ROLE_DRIVER("Driver");

		private String role;

		private UserRole(String role) {
			this.role = role;
		}

		public String value() {
			return this.role;
		}
	}

	public enum ActiveStatus {
		ACTIVE("Active"), DEACTIVATED("Deactivated");

		private String status;

		private ActiveStatus(String status) {
			this.status = status;
		}

		public String value() {
			return this.status;
		}
	}

}
