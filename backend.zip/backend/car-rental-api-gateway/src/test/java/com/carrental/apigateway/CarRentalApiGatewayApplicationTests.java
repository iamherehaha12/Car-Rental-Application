package com.carrental.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
