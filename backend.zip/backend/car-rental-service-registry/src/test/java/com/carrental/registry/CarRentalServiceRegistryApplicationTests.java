package com.carrental.registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
