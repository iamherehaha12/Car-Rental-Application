package com.carrental.car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalCarServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
